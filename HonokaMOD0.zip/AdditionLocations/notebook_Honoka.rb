﻿# notebook_Honoka
gs'gs_inv_show'

'<div id ="main-show-menu-notebook-bg"><img src="pic/interface/notebook-bg.jpg"></div>'
'<div id ="main-show-menu-notebook-stats">'
	'<p><span>统计</span></p>'
	'<p>口交 <<$data[''bj_Honoka'']>> 次(a)</p>'
	'<p>性交 <<$data[''sex_Honoka'']>> 次(a)</p>'
	'<p>肛交 <<$data[''anal_Honoka'']>> 次(a)</p>'
'</div>'
'<div id ="main-show-menu-notebook-img"><img src="pic/diary/honoka.png"></div>'

'<div id ="main-show-menu-notebook-text">'
	我刚认识这名女孩。
'</div>'

'<a href="exec:gt ''notebook''"><div id ="back-img"></div></a>'
